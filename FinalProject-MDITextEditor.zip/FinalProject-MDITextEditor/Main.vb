﻿'Name:          Andrew Rocha
'ID:            100590342
'Date Created:  April 15th, 2019
'Purpose:       Lab 6: MDI Text Editor (Final Project)
'Description:   A client that had commissioned the new text editor is now asking to have it modified to
'               allow multiple text documents To be opened at the same time. They also require that the
'               Average Units Sold by Employee form be included As an additional form In the MDI. 
'

Option Strict On
Imports System.IO
Public Class frmMain
    Private Sub mnuNew_Click(sender As Object, e As EventArgs) Handles mnuNew.Click
        'Create new text file'
        Dim textFile As New TextFile
        textFile.Show()
        textFile.MdiParent = Me
    End Sub

    Private Sub mnuOpen_Click(sender As Object, e As EventArgs) Handles mnuOpen.Click
        'Open text file'
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim newTextForm As New TextFile
            newTextForm.MdiParent = Me

            Try
                Dim inputStream As New StreamReader(OpenFileDialog1.FileName)
                newTextForm.txtUserInput.Text = inputStream.ReadToEnd
                inputStream.Close()
                newTextForm.Show()
            Catch ex As Exception
                Console.WriteLine(ex.ToString())
            End Try

        End If
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'Exit the program'
        Application.Exit()
    End Sub

    Private Sub mnuClose_Click(sender As Object, e As EventArgs) Handles mnuClose.Click
        'Close active form'
        ActiveForm.Close()
    End Sub
    Private Sub Save(pathFileSave As String)

        Dim fileStream As New FileStream(pathFileSave, FileMode.Create, FileAccess.Write)
        Dim writeStream As New StreamWriter(fileStream)
        Dim textForm As New TextFile

        writeStream.Write(textForm.txtUserInput.Text)
        writeStream.Close()

    End Sub
    Private Sub mnuSave_Click(sender As Object, e As EventArgs) Handles mnuSave.Click

        Dim pathOfFile As String = String.Empty ' File path for user created file '
        Dim saveFile As New SaveFileDialog ' Opens save dialog box '
        saveFile.Filter = "Txt files (*.txt)|*.txt"
        'Establish active form'
        Dim activeForm As TextFile = CType(Me.ActiveMdiChild, TextFile)

        ' If dialog box opens, user will continue to save a file '
        If saveFile.ShowDialog() = DialogResult.OK Then

            pathOfFile = saveFile.FileName
            Save(pathOfFile)

        End If
    End Sub

    Private Sub mnuSaveAs_Click(sender As Object, e As EventArgs) Handles mnuSaveAs.Click

        Dim saveFile As New SaveFileDialog ' Opens save dialog box '
        Dim savingFile As String ' Saves file '
        saveFile.Filter = "Txt files (*.txt)|*.txt"
        'Establish active form'
        Dim activeForm As TextFile = CType(Me.ActiveMdiChild, TextFile)

        ' If dialog box opens, user will continue to save a file '
        If saveFile.ShowDialog() = DialogResult.OK Then

            savingFile = saveFile.FileName
            Dim streamWriter As New StreamWriter(savingFile)

            streamWriter.Write(activeForm.txtUserInput.Text)
            streamWriter.Close()

        End If
    End Sub

    Private Sub mnuCopy_Click(sender As Object, e As EventArgs) Handles mnuCopy.Click
        'Establish active form'
        Dim activeForm As TextFile = CType(Me.ActiveMdiChild, TextFile)

        ' Copies highlighted text '
        If String.IsNullOrEmpty(activeForm.txtUserInput.Text.ToString()) Then

        Else

            My.Computer.Clipboard.SetText(activeForm.txtUserInput.SelectedText)

        End If

    End Sub

    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click
        'Establish active form'
        Dim activeForm As TextFile = CType(Me.ActiveMdiChild, TextFile)

        ' Cuts highlighted text '
        If String.IsNullOrEmpty(activeForm.txtUserInput.Text.ToString()) Then

        Else

            My.Computer.Clipboard.SetText(activeForm.txtUserInput.SelectedText)
            activeForm.txtUserInput.SelectedText = ""

        End If

    End Sub

    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click
        'Establish active form'
        Dim activeForm As TextFile = CType(Me.ActiveMdiChild, TextFile)

        ' Pastes previously copied text '
        activeForm.txtUserInput.SelectedText() = My.Computer.Clipboard.GetText()

    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click

        ' Displays message about the program '
        MessageBox.Show("NETD-2202" & vbCrLf & "Lab# 6" & vbCrLf & "Andrew Rocha")

    End Sub

    Private Sub mnuAverageUnits_Click(sender As Object, e As EventArgs) Handles mnuAverageUnits.Click
        'Display Average Untis Shipped program'
        Dim averageUntis As New frmAverageUnitsShipped
        averageUntis.Show()
        averageUntis.MdiParent = Me
    End Sub

    Private Sub mnuTileVertical_Click(sender As Object, e As EventArgs) Handles mnuTileVertical.Click
        'Set the tile to vertical'
        Me.LayoutMdi(System.Windows.Forms.MdiLayout.TileVertical)
    End Sub

    Private Sub mnuCascade_Click(sender As Object, e As EventArgs) Handles mnuCascade.Click
        'Set to cascade'
        Me.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade)
    End Sub

    Private Sub mnuTileHorizontal_Click(sender As Object, e As EventArgs) Handles mnuTileHorizontal.Click
        'Set tile to horizontal'
        Me.LayoutMdi(System.Windows.Forms.MdiLayout.TileHorizontal)
    End Sub
End Class
