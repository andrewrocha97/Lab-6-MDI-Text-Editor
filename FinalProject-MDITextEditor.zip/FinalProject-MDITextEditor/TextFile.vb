﻿Public Class TextFile

End Class