﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShipped
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtUnits = New System.Windows.Forms.TextBox()
        Me.lblEmployee1 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.txtEmployee1Units = New System.Windows.Forms.TextBox()
        Me.txtEmployee2Units = New System.Windows.Forms.TextBox()
        Me.txtEmployee3Units = New System.Windows.Forms.TextBox()
        Me.lblEmployee1Average = New System.Windows.Forms.Label()
        Me.lblEmployee2Average = New System.Windows.Forms.Label()
        Me.lblEmployee3Average = New System.Windows.Forms.Label()
        Me.lblTotalAverage = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblDays
        '
        Me.lblDays.Location = New System.Drawing.Point(13, 13)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(50, 23)
        Me.lblDays.TabIndex = 0
        Me.lblDays.Text = "Day 1"
        '
        'lblUnits
        '
        Me.lblUnits.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblUnits.Location = New System.Drawing.Point(14, 40)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(34, 23)
        Me.lblUnits.TabIndex = 1
        Me.lblUnits.Text = "&Units:"
        '
        'txtUnits
        '
        Me.txtUnits.Location = New System.Drawing.Point(54, 37)
        Me.txtUnits.Name = "txtUnits"
        Me.txtUnits.Size = New System.Drawing.Size(58, 20)
        Me.txtUnits.TabIndex = 2
        Me.ttToolTip.SetToolTip(Me.txtUnits, "Enter the Amount of Units the Employee has Shipped")
        '
        'lblEmployee1
        '
        Me.lblEmployee1.AutoSize = True
        Me.lblEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee1.Location = New System.Drawing.Point(29, 71)
        Me.lblEmployee1.Name = "lblEmployee1"
        Me.lblEmployee1.Size = New System.Drawing.Size(72, 13)
        Me.lblEmployee1.TabIndex = 3
        Me.lblEmployee1.Text = "Employee 1"
        '
        'lblEmployee2
        '
        Me.lblEmployee2.AutoSize = True
        Me.lblEmployee2.Location = New System.Drawing.Point(139, 71)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(62, 13)
        Me.lblEmployee2.TabIndex = 4
        Me.lblEmployee2.Text = "Employee 2"
        '
        'lblEmployee3
        '
        Me.lblEmployee3.AutoSize = True
        Me.lblEmployee3.Location = New System.Drawing.Point(243, 71)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(62, 13)
        Me.lblEmployee3.TabIndex = 5
        Me.lblEmployee3.Text = "Employee 3"
        '
        'txtEmployee1Units
        '
        Me.txtEmployee1Units.BackColor = System.Drawing.SystemColors.Window
        Me.txtEmployee1Units.Location = New System.Drawing.Point(12, 87)
        Me.txtEmployee1Units.Multiline = True
        Me.txtEmployee1Units.Name = "txtEmployee1Units"
        Me.txtEmployee1Units.ReadOnly = True
        Me.txtEmployee1Units.Size = New System.Drawing.Size(100, 120)
        Me.txtEmployee1Units.TabIndex = 6
        Me.ttToolTip.SetToolTip(Me.txtEmployee1Units, "Units shipped by Employee 1 will be Displayed here")
        '
        'txtEmployee2Units
        '
        Me.txtEmployee2Units.BackColor = System.Drawing.SystemColors.Window
        Me.txtEmployee2Units.Location = New System.Drawing.Point(118, 87)
        Me.txtEmployee2Units.Multiline = True
        Me.txtEmployee2Units.Name = "txtEmployee2Units"
        Me.txtEmployee2Units.ReadOnly = True
        Me.txtEmployee2Units.Size = New System.Drawing.Size(100, 120)
        Me.txtEmployee2Units.TabIndex = 7
        Me.ttToolTip.SetToolTip(Me.txtEmployee2Units, "Units shipped by Employee 2 will be Displayed here")
        '
        'txtEmployee3Units
        '
        Me.txtEmployee3Units.BackColor = System.Drawing.SystemColors.Window
        Me.txtEmployee3Units.Location = New System.Drawing.Point(224, 87)
        Me.txtEmployee3Units.Multiline = True
        Me.txtEmployee3Units.Name = "txtEmployee3Units"
        Me.txtEmployee3Units.ReadOnly = True
        Me.txtEmployee3Units.Size = New System.Drawing.Size(100, 120)
        Me.txtEmployee3Units.TabIndex = 8
        Me.ttToolTip.SetToolTip(Me.txtEmployee3Units, "Units shipped by Employee 3 will be Displayed here")
        '
        'lblEmployee1Average
        '
        Me.lblEmployee1Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee1Average.Location = New System.Drawing.Point(12, 214)
        Me.lblEmployee1Average.Name = "lblEmployee1Average"
        Me.lblEmployee1Average.Size = New System.Drawing.Size(100, 25)
        Me.lblEmployee1Average.TabIndex = 9
        Me.lblEmployee1Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttToolTip.SetToolTip(Me.lblEmployee1Average, "The Average for Employee 1 will be Displayed here")
        '
        'lblEmployee2Average
        '
        Me.lblEmployee2Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee2Average.Location = New System.Drawing.Point(118, 214)
        Me.lblEmployee2Average.Name = "lblEmployee2Average"
        Me.lblEmployee2Average.Size = New System.Drawing.Size(100, 25)
        Me.lblEmployee2Average.TabIndex = 10
        Me.lblEmployee2Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttToolTip.SetToolTip(Me.lblEmployee2Average, "The Average for Employee 2 will be Displayed here")
        '
        'lblEmployee3Average
        '
        Me.lblEmployee3Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee3Average.Location = New System.Drawing.Point(224, 214)
        Me.lblEmployee3Average.Name = "lblEmployee3Average"
        Me.lblEmployee3Average.Size = New System.Drawing.Size(100, 25)
        Me.lblEmployee3Average.TabIndex = 11
        Me.lblEmployee3Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttToolTip.SetToolTip(Me.lblEmployee3Average, "The Average for Employee 3 will be Displayed here")
        '
        'lblTotalAverage
        '
        Me.lblTotalAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalAverage.Location = New System.Drawing.Point(13, 243)
        Me.lblTotalAverage.Name = "lblTotalAverage"
        Me.lblTotalAverage.Size = New System.Drawing.Size(311, 23)
        Me.lblTotalAverage.TabIndex = 12
        Me.lblTotalAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttToolTip.SetToolTip(Me.lblTotalAverage, "The Average for all the Employees will be Displayed here")
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(12, 270)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(100, 23)
        Me.btnEnter.TabIndex = 13
        Me.btnEnter.Text = "&Enter"
        Me.ttToolTip.SetToolTip(Me.btnEnter, "Press this to Enter units for the Employee")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(118, 270)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(100, 23)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.ttToolTip.SetToolTip(Me.btnReset, "Press this to Reset the Program")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(224, 270)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(100, 23)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "E&xit"
        Me.ttToolTip.SetToolTip(Me.btnExit, "Press this to End the Program")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmAverageUnitsShipped
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(332, 304)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblTotalAverage)
        Me.Controls.Add(Me.lblEmployee3Average)
        Me.Controls.Add(Me.lblEmployee2Average)
        Me.Controls.Add(Me.lblEmployee1Average)
        Me.Controls.Add(Me.txtEmployee3Units)
        Me.Controls.Add(Me.txtEmployee2Units)
        Me.Controls.Add(Me.txtEmployee1Units)
        Me.Controls.Add(Me.lblEmployee3)
        Me.Controls.Add(Me.lblEmployee2)
        Me.Controls.Add(Me.lblEmployee1)
        Me.Controls.Add(Me.txtUnits)
        Me.Controls.Add(Me.lblUnits)
        Me.Controls.Add(Me.lblDays)
        Me.MaximumSize = New System.Drawing.Size(348, 343)
        Me.MinimumSize = New System.Drawing.Size(348, 343)
        Me.Name = "frmAverageUnitsShipped"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped By Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDays As Label
    Friend WithEvents lblUnits As Label
    Friend WithEvents txtUnits As TextBox
    Friend WithEvents lblEmployee1 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents txtEmployee1Units As TextBox
    Friend WithEvents txtEmployee2Units As TextBox
    Friend WithEvents txtEmployee3Units As TextBox
    Friend WithEvents lblEmployee1Average As Label
    Friend WithEvents lblEmployee2Average As Label
    Friend WithEvents lblEmployee3Average As Label
    Friend WithEvents ttToolTip As ToolTip
    Friend WithEvents lblTotalAverage As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
End Class
