﻿'Name:          Andrew Rocha
'ID:            100590342
'Date Created:  February 19th, 2019
'Purpose:       Lab 3 - Average Units Shipped By Employee
'Description:   Your solution will take an input for each day in the week numbered
'               from 1 To 7, but the functionality will be extended To record the
'               information For 3 employees. The user input data will need To be
'               validated And, If it passes validation, the data will need To be
'               displayed To the user. Once the number Of units has been entered
'               For the 7th day For the  3Rd employee the solution will calculate
'               and display the average per employee, as well as, the company
'               average.  
'

Option Strict On
Public Class frmAverageUnitsShipped

    Const MINIMUM_UNITS As Integer = 0 ' Minimum amount of units user must enter '
    Const MAXIMUM_UNITS As Integer = 1000 ' Maximum amount of units user must enter '
    Const MAXIMUM_DAYS As Integer = 7 ' Maximum amount of days in the week '
    Const NUMBER_OF_EMPLOYEES As Integer = 3 ' Maximum amount of employees '

    Dim userInput As String = String.Empty ' User input taken and stored into this variable '
    Dim unitsArray(NUMBER_OF_EMPLOYEES - 1, MAXIMUM_DAYS - 1) As Integer ' 2D Array to store all values through week from each employee'
    Dim unitValue As Integer ' The value of the unit entered '
    Dim day As Integer = 1 ' The day counter '
    Dim presentRow As Integer = 0 ' The current row the user is on '
    Dim presentColumn As Integer = 0 ' The current column the user is on '

    Dim employee1Average As Double ' Average of the units in the week from employee 1 '
    Dim employee2Average As Double ' Average of the units in the week from employee 2 '
    Dim employee3Average As Double ' Average of the units in the week from employee 3 '
    Dim totalAverage As Double ' Average per day of all employees '
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        ' Ends the program '
        Application.Exit()

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Set focus back on the user input textbox to start over '
        txtUnits.Focus()
        ' Clear all employee units textboxes and user input textbox '
        txtEmployee1Units.Clear()
        txtEmployee2Units.Clear()
        txtEmployee3Units.Clear()
        txtUnits.Clear()
        ' Reset the labels to its default values (which is nothing) '
        lblEmployee1Average.ResetText()
        lblEmployee2Average.ResetText()
        lblEmployee3Average.ResetText()
        ' Enable the enter button for user to enter in the units '
        btnEnter.Enabled = True
        ' Enable the textbox for user to type in units '
        txtUnits.ReadOnly = False
        ' Change employee 1 font to bold and change the other employees font to regular'
        lblEmployee1.Font = New Font(lblEmployee1.Font, FontStyle.Bold)
        lblEmployee2.Font = New Font(lblEmployee2.Font, FontStyle.Regular)
        lblEmployee3.Font = New Font(lblEmployee3.Font, FontStyle.Regular)
        ' Set all values back to its original state '
        day = 1
        employee1Average = 0
        employee2Average = 0
        employee3Average = 0
        totalAverage = 0
        unitValue = 0
        userInput = String.Empty
        lblDays.Text = "Day 1"
        ReDim unitsArray(NUMBER_OF_EMPLOYEES - 1, MAXIMUM_DAYS - 1)
        presentColumn = 0
        presentRow = 0

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        userInput = txtUnits.Text

        ' Check validation using a function '
        If Validation(userInput, unitValue) = False Then
            ' If users validation fails, prompt user to enter correct input '
            MessageBox.Show("Please ensure the units shipped are between " & MINIMUM_UNITS.ToString() & " and " & MAXIMUM_UNITS.ToString() & "!")
            ' Clear user input textbox and focus on it '
            txtUnits.Clear()
            txtUnits.Focus()

        Else
            ' Setting the user input into the current index of the array '
            unitsArray(presentRow, presentColumn) = unitValue

            ' Each row of the array is each employee. Until user enters 7 set of units for one employee, the user can't move on to the next row '
            If presentRow = 0 Then
                txtEmployee1Units.Text += unitsArray(presentRow, presentColumn) & vbCrLf
            ElseIf presentRow = 1 Then
                txtEmployee2Units.Text += unitsArray(presentRow, presentColumn) & vbCrLf
            ElseIf presentRow = 2 Then
                txtEmployee3Units.Text += unitsArray(presentRow, presentColumn) & vbCrLf
            End If

            ' Check to see if the user is under the 7th day '
            If day < MAXIMUM_DAYS Then
                ' Add a day '
                day += 1
                ' Display what day it is '
                lblDays.Text = "Day " & day.ToString()
                ' Clear user input textbox and focus on it '
                txtUnits.Clear()
                txtUnits.Focus()
            End If

            ' Go on to the next column of the array ' 
            presentColumn += 1

            ' Check if employee 1 has entered all units for the week '
            If presentRow = 0 And presentColumn > (MAXIMUM_DAYS - 1) Then
                For counter As Integer = 0 To (MAXIMUM_DAYS - 1)
                    ' Add up total units for employee 1 '
                    employee1Average = employee1Average + unitsArray(presentRow, counter)
                Next
                ' Calculate employees 1 average '
                employee1Average = employee1Average / MAXIMUM_DAYS
                ' Display employees 1 average rounded to 2 in their output label '
                lblEmployee1Average.Text = "Average: " & Math.Round(employee1Average, 2)
                ' Change employee 1 font to regular and employee 2 font to bold '
                lblEmployee1.Font = New Font(lblEmployee1.Font, FontStyle.Regular)
                lblEmployee2.Font = New Font(lblEmployee2.Font, FontStyle.Bold)
            End If

            ' Check if employee 2 has entered all units for the week '
            If presentRow = 1 And presentColumn > (MAXIMUM_DAYS - 1) Then
                For counter As Integer = 0 To (MAXIMUM_DAYS - 1)
                    ' Add up total units for employee 2 '
                    employee2Average = employee2Average + unitsArray(presentRow, counter)
                Next
                ' Calculate employees 1 average '
                employee2Average = employee2Average / MAXIMUM_DAYS
                ' Display employees 2 average rounded to 2 in their output label '
                lblEmployee2Average.Text = "Average: " & Math.Round(employee2Average, 2)
                ' Change employee 2 font to regular and employee 3 font to bold '
                lblEmployee2.Font = New Font(lblEmployee2.Font, FontStyle.Regular)
                lblEmployee3.Font = New Font(lblEmployee3.Font, FontStyle.Bold)
            End If

            ' Check if employee 3 has entered all units for the week '
            If presentRow = 2 And presentColumn > (MAXIMUM_DAYS - 1) Then
                For counter As Integer = 0 To (MAXIMUM_DAYS - 1)
                    ' Add up total units for employee 3 '
                    employee3Average = employee3Average + unitsArray(presentRow, counter)
                Next
                ' Calculate employees 1 average '
                employee3Average = employee3Average / MAXIMUM_DAYS
                ' Display employees 3 average rounded to 2 in their output label '
                lblEmployee3Average.Text = "Average: " & Math.Round(employee3Average, 2)
                ' Change employee 1 font to bold and employee 3 font to regular '
                lblEmployee1.Font = New Font(lblEmployee1.Font, FontStyle.Bold)
                lblEmployee3.Font = New Font(lblEmployee3.Font, FontStyle.Regular)

                ' After all employees averages has been calculated, now it's time to calculate the total average '
                ' Disable the enter button '
                btnEnter.Enabled = False
                ' Clear user input textbox and set it to read only '
                txtUnits.ReadOnly = True
                txtUnits.Clear()
                ' Set focus on the reset button in case user wants to start over the program '
                btnReset.Focus()
                ' Calculate the total average per day of all employees '
                totalAverage = (employee1Average + employee2Average + employee3Average) / NUMBER_OF_EMPLOYEES
                ' Display total average per day in the ouput label'
                lblTotalAverage.Text = "Average per day: " & Math.Round(totalAverage, 2)
                ' Display "Done" on the day counter label '
                lblDays.Text = "Done"
            End If
        End If

        ' Check if user has entered all 7 days of units for the employee '
        If presentColumn = MAXIMUM_DAYS Then
            presentRow += 1
            presentColumn = 0
        End If
        ' If the day counter hits 7, go on to the next employee
        If day > MAXIMUM_DAYS - 1 Then day = 0


    End Sub
    Private Function Validation(ByVal usersInput As String, ByRef userValidation As Integer) As Boolean

        Dim finalValue As Boolean = True
        Dim unitValue As Integer

        ' Check if users input is a whole number '
        If (Integer.TryParse(usersInput, unitValue)) Then

            ' Check if users input is within range (0 and 1000) '
            If unitValue >= MINIMUM_UNITS AndAlso unitValue <= MAXIMUM_UNITS Then
                userValidation = unitValue
                ' If users input passes all validation, the function will return a true value '
                finalValue = True

            Else
                ' If users input is not within range, the function will return a false value '
                finalValue = False
            End If

        Else
            ' If users input is not a whole numeric value, the function will return a false value '
            finalValue = False
        End If

        ' Return the value whether it's false or true '
        Return finalValue

    End Function
End Class
